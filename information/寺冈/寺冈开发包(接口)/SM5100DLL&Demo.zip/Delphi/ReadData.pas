unit ReadData;

interface

uses
  Classes{$IFDEF MSWINDOWS}, Windows{$ENDIF}, WinSock, SysUtils;

type
  TReadData = class(TThread)
  private
    ScaleID: Integer;
  public
    procedure setScaleID(ScaleID: Integer);
    procedure ReadReceiptDetail();
    procedure ReadReceiptTotal();
    procedure ReadStockOperation();

   // constructor create(Scale: TScale; SMFileNo: Integer);
   // destructor Destroy; override;

  protected
    procedure Execute; override;

  end;

implementation
uses
  Scale, SalesReceipt,Stock, ScaleAPI;

procedure TReadData.setScaleID(ScaleID: Integer);
begin
  Self.ScaleID := ScaleID;
end;

procedure TReadData.Execute;
const
  SEMAPHORE_ALL_ACCESS = $1F0003;
var
  SmHandle: THandle;
  hMutex: THandle; //
begin
  SmHandle := OpenSemaphore(SEMAPHORE_ALL_ACCESS, False, 'ReadThreads');
  WaitForSingleObject(SmHandle, INFINITE);
  try
    //�߳̿�ʼ��־
    G_CommMonitor[scaleID].Resume;
    G_ScaleList[scaleID].ScaleThreadStat := 1;
    case G_ScaleList[scaleID].FileNo of
      $51: ReadReceiptDetail; //������ϸ
      $52: ReadReceiptTotal; //���ۺϼ�
      $A2: ReadStockOperation; //������
    end;
  finally
    //�߳̽���
    G_ScaleList[scaleID].ScaleThreadStat := 0;
    ReleaseSemaphore(SmHandle, 1, nil);
    if SmHandle<>0 then CloseHandle(SmHandle);
    hMutex :=OpenMutex(MUTEX_ALL_ACCESS,False,PChar('ReadThreadMutex'));
    WaitForSingleObject(hMutex,INFINITE);
    Dec(G_ScaleCommThreadCount);
    ReleaseMutex(hMutex);
    if hMutex<>0 then CloseHandle(hMutex);
  end;
end;

procedure TReadData.ReadReceiptDetail();
var
  s: TSocket; //
  ScaleReceipts: TReceiptDetail; //
  ReceiptRecord: ReceiptDetail;  //
  RecNo: Integer;
begin
  s := 0;
  RecNo := 0;
  ScaleReceipts := TReceiptDetail.create;
  try
    ScaleReceipts.setStoreNo(G_ScaleList[ScaleID].StoreNo);
    ScaleReceipts.setStoreName(G_ScaleList[ScaleID].storeName);
    ScaleReceipts.setScaleNo(G_ScaleList[ScaleID].ScaleNo);

    ZeroMemory(@ReceiptRecord, SizeOf(ReceiptDetail));
    //���ӵ���
    s := ConnectScale(PChar(G_ScaleList[ScaleID].InterIP), G_ScaleList[ScaleID].PortNo); //���� socket ����
    if (s > 0) then //���ӳɹ�
    begin
      while True do begin
         G_ScaleList[ScaleID].CommResult := ScaleAPI.ReadReceiptDetail(s, @ReceiptRecord, RecNo); //���ս�����ϸ����
        case G_ScaleList[ScaleID].CommResult of
          $0:
            begin
              ScaleReceipts.setRecordData(ReceiptRecord);
              //��������1
              Inc(G_ScaleList[ScaleID].CommCount);
              //���浽���ݿ�
              ScaleReceipts.Insert2DB;
              //���ؼ�¼���
              RecNo := ReceiptRecord.RecordNo;
              //
              ZeroMemory(@ReceiptRecord, SizeOf(ReceiptDetail));
              Continue;
            end;
          $E0: Break; //��ȡ����
          $E2: Break; //û������
        else
          Break; //δ����Ĵ���
        end;
      end;
    end;
  finally
    if s > 0 then CloseConnect(s);
    if ScaleReceipts <> nil then ScaleReceipts.Free;
  end;
end;

procedure TReadData.ReadReceiptTotal();
var
  s: TSocket; //
  ScaleReceipts: TReceiptTotal; //
  ReceiptRecord: ReceiptTotal;  //
  RecNo: Integer;  //
begin
  s := 0;
  RecNo := 0;
  ScaleReceipts := TReceiptTotal.create;
  try
    ScaleReceipts.setStoreNo(G_ScaleList[ScaleID].StoreNo);
    ScaleReceipts.setStoreName(G_ScaleList[ScaleID].storeName);
    ScaleReceipts.setScaleNo(G_ScaleList[ScaleID].ScaleNo);
    //
    ZeroMemory(@ReceiptRecord, SizeOf(ReceiptTotal));
    //���ӵ���
    s := ConnectScale(PChar(G_ScaleList[ScaleID].InterIP), G_ScaleList[ScaleID].PortNo); //���� socket ����
    if (s > 0) then //���ӳɹ�
    begin
      while True do begin
         G_ScaleList[ScaleID].CommResult := ScaleAPI.ReadReceiptTotal(s, @ReceiptRecord, RecNo); //���ս�����ϸ����
        case G_ScaleList[ScaleID].CommResult of
          $0:
            begin
              ScaleReceipts.setRecordData(ReceiptRecord);
              //��������1
              Inc(G_ScaleList[ScaleID].CommCount);
              //���浽���ݿ�
              ScaleReceipts.Insert2DB;
              //���ؼ�¼���
              RecNo := ReceiptRecord.RecordNo;
              //
              ZeroMemory(@ReceiptRecord, SizeOf(ReceiptDetail));
              Continue;
            end;
          $E0: Break; //��ȡ����
          $E2: Break; //û������
        else
          Break; //δ����Ĵ���
        end;
      end;
    end;
  finally
    if s > 0 then CloseConnect(s);
    if ScaleReceipts <> nil then ScaleReceipts.Free;
  end;
end;

procedure TReadData.ReadStockOperation();
var
  s: TSocket; //
  StockdateOpt: TStockOperation; //
  StockData: StockRecord;  //
  RecNo: Integer;  //
begin
  s := 0;
  RecNo := 0;
  StockdateOpt := TStockOperation.create;
  try
    StockdateOpt.setStoreNo(G_ScaleList[ScaleID].StoreNo);
    StockdateOpt.setStoreName(G_ScaleList[ScaleID].storeName);
    StockdateOpt.setScaleNo(G_ScaleList[ScaleID].ScaleNo);
    //
    ZeroMemory(@StockData, SizeOf(StockRecord));

    //���ӵ���
    s :=ConnectScale(PChar(G_ScaleList[ScaleID].InterIP), G_ScaleList[ScaleID].PortNo); //���� socket ����
    if (s > 0) then //���ӳɹ�
    begin
      while True do begin
          G_ScaleList[ScaleID].CommResult :=ScaleAPI.ReadStock(s, @StockData, RecNo); //���ս�����ϸ����
        case G_ScaleList[ScaleID].CommResult of
          $0:
            begin
              StockdateOpt.setRecordData(StockData);
              //��������1
              Inc(G_ScaleList[ScaleID].CommCount);
              //���浽���ݿ�
              StockdateOpt.Insert2DB(StockData);
              //���ؼ�¼���
              RecNo := StockData.RecordNo;
              //
              ZeroMemory(@StockData, SizeOf(StockRecord));
              Continue;
            end;
          $E0: Break; //��ȡ����
          $E2: Break; //û������
        else
          Break; //δ����Ĵ���
        end;
      end;
    end;
  finally
    if s > 0 then CloseConnect(s);
    if StockdateOpt <> nil then StockdateOpt.Free;
  end;
end;

end.

