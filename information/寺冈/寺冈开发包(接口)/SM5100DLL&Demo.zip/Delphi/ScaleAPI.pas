unit ScaleAPI;

interface
uses
  WinSock,PLU,
  SalesReceipt,Stock,
  ScaleData,Password,
  PreSetKey,Traceability,
  ShopName,FlexiBarcode,
  SalesTotal;

function ConnectScale(scaleIP: string; PortNo: Integer): TSocket; stdcall; external 'SMScaleAPI.dll';
function CloseConnect(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//PLU�ļ�
function SendRPlu(s: TSocket; PLUData: PReceiptPLU): Integer; stdcall; external 'SMScaleAPI.dll';
function SendLPlu(s: TSocket; PLUData: PLabelPLU): Integer; stdcall; external 'SMScaleAPI.dll';
function RDPluFAsReceipt(s: TSocket; RecordNo: Integer; RPLUData: PReceiptPLU): Integer; stdcall; external 'SMScaleAPI.dll';
function RDPluFAsLabel(s: TSocket; RecordNo: Integer; LPLUData: PLabelPLU): Integer; stdcall; external 'SMScaleAPI.dll';
//������ϸ
function ReadReceiptDetail(s: TSocket; RecordNo: Integer;ReceiptData: PReceiptDetail): Integer; stdcall; external 'SMScaleAPI.dll';
function DelReceiptDetailRD(s: TSocket; RecordNo: Integer): Integer; stdcall; external 'SMScaleAPI.dll';
//���ۺϼ�
function ReadReceiptTotal(s: TSocket; RecordNo: Integer; ReceiptData: PReceiptTotal): Integer; stdcall; external 'SMScaleAPI.dll';
function DelReceiptTotalRD(s: TSocket; RecordNo: Integer): Integer; stdcall; external 'SMScaleAPI.dll';
//��ǩ����
function ReadPLUTTLTrans(s: TSocket; RecordNo: Integer;PLUTTLTrans: PPlu_T_Transaction): Integer; stdcall; external 'SMScaleAPI.dll';
function DelPLUTTLTrans(s: TSocket; RecordNo: Integer): Integer; stdcall; external 'SMScaleAPI.dll';
//�������ļ�
function ReadStock(s: TSocket; RecordNo: Integer; StockOpt: PStockRecord): Integer; stdcall; external 'SMScaleAPI.dll';
function DelStockRD(s: TSocket; RecordNo: Integer): Integer; stdcall; external 'SMScaleAPI.dll';
//ͬ��ʱ��
function SyncDateTime(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//������Ϣ
function ReadScaleData(s: TSocket; RecordNo: Integer; ScaleInfo: PScaleInfo): Integer; stdcall; external 'SMScaleAPI.dll';
//�����ļ�
function ReadPassword(s: TSocket; RecordNo: Integer; ppwd: PSMPwd): Integer; stdcall; external 'SMScaleAPI.dll';
function SendPassword(s: TSocket; ppwd: PSMPwd): Integer; stdcall; external 'SMScaleAPI.dll';
function DelPassword(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//Ԥ���
function ReadPreSetKey(s: TSocket; RecordNo: Integer; ppsk: PPSKey): Integer; stdcall; external 'SMScaleAPI.dll';
function SendPresetKey(s: TSocket; ppsk: PPSKey): Integer; stdcall; external 'SMScaleAPI.dll';
function DelPSKFile(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//׷����
function ReadTraceability(s: TSocket; RecordNo: Integer; pTraceability: PTrace): Integer; stdcall; external 'SMScaleAPI.dll';
function SendTraceability(s: TSocket; pTraceability: PTrace): Integer; stdcall; external 'SMScaleAPI.dll';
//function DelPSKFile(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//����
function ReadShopName(s: TSocket; RecordNo: Integer; pshopname: PShpName): Integer; stdcall; external 'SMScaleAPI.dll';
function SendShopName(s: TSocket; pshopname: PShpName): Integer; stdcall; external 'SMScaleAPI.dll';
function DelSHPFile(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//�Զ�������
function ReadFlexiBarcode(s: TSocket; RecordNo: Integer; pFlxBar: PFlexiBar): Integer; stdcall; external 'SMScaleAPI.dll';
function SendFlexiBarcode(s: TSocket; pFlxBar: PFlexiBar): Integer; stdcall; external 'SMScaleAPI.dll';
//function DelSHPFile(s: TSocket): Integer; stdcall; external 'SMScaleAPI.dll';
//�����ձ���
function ReadSalesDaily(s: TSocket; RecordNo: Integer; pSalesD: PSalesDaily): Integer; stdcall; external 'SMScaleAPI.dll';

implementation

end.

 