unit SendData;

interface

uses
  Classes{$IFDEF MSWINDOWS}, Windows{$ENDIF},
  WinSock, SysUtils,ShellAPI;

type
  TSendData = class(TThread)
  private
    ScaleID: Integer;

    procedure SendPLU();
  public
    procedure setScaleID(ScaleID: Integer);
    //constructor create(Scale: TScale; SMFileNo: Integer);
    //destructor Destroy; override;
  protected
    procedure Execute; override;
  end;

implementation

uses
  PLU, Scale, ScaleAPI;

procedure TSendData.setScaleID(ScaleID: Integer);
begin
  Self.ScaleID := ScaleID;
end;

procedure TSendData.Execute;
const
  SEMAPHORE_ALL_ACCESS = $1F0003;
var
  SmHandle: THandle;
  hMutex: THandle; //
begin
  SmHandle := OpenSemaphore(SEMAPHORE_ALL_ACCESS, False, 'SendThreads');
  WaitForSingleObject(SmHandle, INFINITE);
  try
    //�߳̿�ʼ��־
    G_CommMonitor[scaleID].Resume;
    G_ScaleList[scaleID].ScaleThreadStat := 1;
    case G_ScaleList[scaleID].FileNo of
      $25: SendPLU;   //�´� PLU ����
    end;
  finally
    //�߳̽���
    G_ScaleList[scaleID].ScaleThreadStat := 0;
    ReleaseSemaphore(SmHandle, 1, nil);  //�����ź���
    if SmHandle<>0 then CloseHandle(SmHandle);
    hMutex :=OpenMutex(MUTEX_ALL_ACCESS,False,PChar('SendThreadMutex'));
    WaitForSingleObject(hMutex,INFINITE);
    Dec(G_ScaleCommThreadCount);   //ȫ�ֵ��������е��̼߳�����1
    ReleaseMutex(hMutex);
    if hMutex<>0 then CloseHandle(hMutex);
  end;
end;


procedure TSendData.SendPLU();
var
  s: TSocket; //
  PLUs: TSMReceiptPLU; //
  Records: ReceiptPLUArray;
  i: Integer;
begin
  s := 0;
  PLUs := TSMReceiptPLU.create;
  try
    //���ӵ���
    s := ConnectScale(PChar(G_ScaleList[ScaleID].InterIP), G_ScaleList[ScaleID].PortNo); //���� socket ����
    G_ScaleList[ScaleID].CommCount :=1;
    if (s > 0) then //���ӳɹ�
    begin
       Records := PLUs.GetDBData;
      if Records <> nil then begin
        for i := Low(Records) to High(Records) do begin
          //�õ�PLU���� �´�PLu����
          G_ScaleList[ScaleID].CommResult := ScaleAPI.SendPluData(s, Records[i]); //���ս�����ϸ����
          case G_ScaleList[ScaleID].CommResult of
            $06:
              begin
                //��������1
                Inc(G_ScaleList[ScaleID].CommCount);
                Continue;
              end;
            $E1: Continue;     //д�����
            $E2: Break;     //û���㹻���ڴ�ռ�
          else
            Break; //δ����Ĵ���
          end;
        end;
      end;
    end;
  finally
    if s > 0 then CloseConnect(s);
    if PLUs <> nil then PLUs.Free;
  end;
end;

end.

