unit PreSetKey;

interface
uses
  Classes;

type
  PSKey= record
    RecordNo: Integer;        //��¼���
    RecSize: Integer;
    PageNo: Integer;         //ҳ���
    KeyNo: Integer;          //�����
    KeySwitchNo: Integer;    //������
    Status: Integer;
    CSize: Integer;
    PSKName: array[0..23] of Char;
    ReferFile :Integer;
  end;

  PPSKey = ^PSKey;

implementation


end.

 